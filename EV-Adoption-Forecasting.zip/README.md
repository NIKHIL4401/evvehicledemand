
# EV Adoption Forecasting 🚗⚡

This project focuses on forecasting Electric Vehicle (EV) adoption across counties using machine learning models. It includes exploratory data analysis, feature engineering, and model training with Random Forest.

## 📁 Project Structure

```
EV-Adoption-Forecasting/
├── data/
│   └── Electric_Vehicle_Population_By_County.csv
├── images/
│   └── RF_Tree.png
├── EV_Adoption_Forecasting.ipynb
├── README.md
```

## 📊 Dataset
- Source: Electric Vehicle Population dataset by county
- Contains fields like vehicle make, model, county, type, and more

## 🧠 Models Used
- Random Forest Regressor
- Decision Tree Classifier (visualized)

## 📈 Visuals
- Correlation heatmaps
- Feature importances
- Decision tree diagram (see `images/RF_Tree.png`)

## 🧪 Results
- Forecasting accuracy and insights into top features influencing EV adoption

## 📌 To Do
- Try additional models (XGBoost, SVR)
- Deploy as a simple web app (Streamlit or Flask)
- Use time series data if available

## ▶️ Running the Notebook
Make sure to install the required Python libraries:
```bash
pip install pandas numpy matplotlib seaborn scikit-learn
```

## 🙌 Contributors
Made with ❤️ by Nikhil
